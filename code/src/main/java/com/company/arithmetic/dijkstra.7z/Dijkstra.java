package com.company.arithmetic.dijkstra;

/**
 * 图的最短优先路径
 */
public class Dijkstra {

}
